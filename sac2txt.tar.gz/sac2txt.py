import os
import struct
from datetime import datetime, timedelta
import numpy as np

def read_sac(file_path):
    with open(file_path, 'rb') as f:
        header = f.read(632)  # 读取头部
        data = f.read()  # 读取振幅数据部分
    
    # 解析头部
    floats = struct.unpack('70f', header[:280])  # 70个float32
    ints = struct.unpack('40i', header[280:440])  # 40个int32

    delta = floats[0]  # 原始采样间隔
    npts = ints[9]     # 数据点数
    year = ints[0]
    jday = ints[1]
    hour = ints[2]
    minute = ints[3]
    sec = ints[4]
    msec = ints[5]

    start_time = datetime(year, 1, 1) + timedelta(days=jday-1, hours=hour, minutes=minute, seconds=sec, milliseconds=msec)

    amplitudes = struct.unpack(f'{npts}f', data[:npts*4])  # 解析数据
    amplitudes = np.array(amplitudes)

    return start_time, delta, amplitudes

def downsample(data, original_fs, target_fs):
    """
    简单均匀抽取法降采样
    """
    factor = int(original_fs / target_fs)
    return data[::factor]

def process_sac_files(input_folder, output_folder=None, target_fs=40):
    if not output_folder:
        output_folder = input_folder

    os.makedirs(output_folder, exist_ok=True)

    original_fs = 100  # 已知原采样率100Hz
    original_delta = 1.0 / original_fs  # 原采样间隔
    target_delta = 1.0 / target_fs  # 目标采样间隔

    for filename in os.listdir(input_folder):
        if filename.lower().endswith('.sac'):
            sac_path = os.path.join(input_folder, filename)

            try:
                start_time, delta, amplitudes = read_sac(sac_path)

                # 检查采样率是否一致
                if abs(delta - original_delta) > 1e-6:
                    print(f"警告：{filename} 采样间隔与预期不符 (delta={delta})，已继续处理。")

                # 降采样
                amplitudes_ds = downsample(amplitudes, original_fs, target_fs)

                # 构建时间序列（单位：秒，从0开始）
                npts_ds = len(amplitudes_ds)
                time_seconds = np.arange(0, npts_ds) * target_delta  # 降采样后的时间轴

                # 写入txt
                base_name = os.path.splitext(filename)[0]
                output_txt = os.path.join(output_folder, f"processed.txt")

                np.savetxt(output_txt, np.column_stack((time_seconds, amplitudes_ds)), 
                           fmt='%.6f %.6f', header="Time(s) Amplitude", comments='')

                print(f"成功处理并降采样：{filename} -> {output_txt}")

            except Exception as e:
                print(f"处理失败：{filename}，原因：{e}")

if __name__ == "__main__":
    input_folder = r"E:\大创和科研\Wavelet_Time_Frequency_Analysis\data"
    output_folder = r"E:\大创和科研\Wavelet_Time_Frequency_Analysis\results"

    process_sac_files(input_folder, output_folder, target_fs=40)
