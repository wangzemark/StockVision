import os
import struct
from datetime import datetime, timedelta

def read_sac(file_path):
    with open(file_path, 'rb') as f:
        header = f.read(632)  # 读取头部
        data = f.read()  # 读取剩下的数据（振幅）
    
    # 解析头部
    # SAC头部结构，选出需要的几个信息
    # 注意：前70个float32，之后是整数和字符
    floats = struct.unpack('70f', header[:280])  # 前280字节是70个float32
    ints = struct.unpack('40i', header[280:440])  # 接着是40个int32
    
    # 获取需要的头部参数
    delta = floats[0]  # 采样间隔（秒）
    npts = ints[9]     # 数据点数（第10个int）
    year = ints[0]     # 起始年
    jday = ints[1]     # 起始儒略日
    hour = ints[2]
    minute = ints[3]
    sec = ints[4]
    msec = ints[5]

    # 解析起始时间
    start_time = datetime(year, 1, 1) + timedelta(days=jday-1, hours=hour, minutes=minute, seconds=sec, milliseconds=msec)

    # 解析振幅数据
    amplitudes = struct.unpack(f'{npts}f', data[:npts*4])  # 每个float32是4字节

    return start_time, delta, amplitudes

def process_sac_files(input_folder, output_folder=None):
    if not output_folder:
        output_folder = input_folder

    os.makedirs(output_folder, exist_ok=True)

    for filename in os.listdir(input_folder):
        if filename.lower().endswith('.sac'):
            sac_path = os.path.join(input_folder, filename)

            try:
                start_time, delta, amplitudes = read_sac(sac_path)
                base_name = os.path.splitext(filename)[0]
                output_txt = os.path.join(output_folder, f"{base_name}_processed.txt")

                with open(output_txt, 'w') as f:
                    f.write("Timestamp Amplitude\n")
                    for i, amp in enumerate(amplitudes):
                        ts = start_time + timedelta(seconds=i * delta)
                        ts_str = ts.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]  # 到毫秒
                        f.write(f"{ts_str} {amp}\n")

                print(f"成功处理：{filename} -> {output_txt}")

            except Exception as e:
                print(f"处理失败：{filename}，原因：{e}")

if __name__ == "__main__":
    input_folder = r"E:\大创和科研\Wavelet_Time_Frequency_Analysis\data"
    output_folder = r"E:\大创和科研\Wavelet_Time_Frequency_Analysis\results"

    process_sac_files(input_folder, output_folder)
